"""Post-processor for OpenAPI-generated client code.

Fixes issues that ansible-test sanity flags in generated files:
  1. Replaces bare ``assert`` statements (including multi-line) with
     ``if / raise AssertionError`` (ansible-test no-assert rule).
  2. Removes redundant ``import X as X`` re-aliasing to shorten lines.
  3. Wraps long ``from … import`` lines (>160 chars) into parenthesized form.
  4. Adds ``# noqa: E501`` to remaining long lines that cannot be split.

Usage:
    python fix_sanity.py <directory>
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

MAX_LINE_LENGTH = 160

ANSIBLE_BOILERPLATE = (
    'from __future__ import (absolute_import, division, print_function)\n'
    '__metaclass__ = type\n'
)


# ---------------------------------------------------------------------------
# assert  →  if / raise
# ---------------------------------------------------------------------------

def fix_asserts(text: str) -> str:
    """Replace all ``assert …`` statements, including multi-line ones."""

    def _replace_single_line(m: re.Match) -> str:
        indent = m.group(1)
        rest = m.group(2).rstrip()
        condition, message = _split_assert(rest)
        negated = _negate(condition)
        if message:
            return f'{indent}if {negated}:\n{indent}    raise AssertionError({message})'
        return f'{indent}if {negated}:\n{indent}    raise AssertionError'

    def _replace_multiline(m: re.Match) -> str:
        """Handle ``assert expr in [\n  …\n]`` spanning multiple lines."""
        indent = m.group(1)
        expr = m.group(2).strip()
        items_block = m.group(3)
        return (
            f'{indent}if {expr} not in [\n'
            f'{items_block}\n'
            f'{indent}]:\n'
            f'{indent}    raise AssertionError(\n'
            f'{indent}        f"Unexpected value: {{{expr}}}"\n'
            f'{indent}    )'
        )

    # Multi-line: assert X in [\n ...\n        ]
    text = re.sub(
        r'^(\s*)assert\s+(\S+)\s+in\s+\[\s*\n(.*?)\n\s*\]',
        _replace_multiline,
        text,
        flags=re.MULTILINE | re.DOTALL,
    )

    # Single-line asserts (must run after multi-line to avoid partial matches)
    text = re.sub(
        r'^(\s*)assert\s+(.+)$',
        _replace_single_line,
        text,
        flags=re.MULTILINE,
    )

    return text


def _split_assert(rest: str):
    """Split ``condition, message`` respecting brackets."""
    depth = 0
    comma_pos = None
    for i, ch in enumerate(rest):
        if ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
        elif ch == ',' and depth == 0:
            comma_pos = i
    if comma_pos is not None:
        return rest[:comma_pos].rstrip(), rest[comma_pos + 1:].strip()
    return rest, None


def _negate(condition: str) -> str:
    if condition.startswith('not '):
        return condition[4:]
    if ' is not ' in condition:
        return condition.replace(' is not ', ' is ', 1)
    if ' not in ' in condition:
        return condition.replace(' not in ', ' in ', 1)
    if ' in ' in condition:
        return condition.replace(' in ', ' not in ', 1)
    if ' is ' in condition:
        return condition.replace(' is ', ' is not ', 1)
    return f'not ({condition})'


# ---------------------------------------------------------------------------
# Line-level fixes
# ---------------------------------------------------------------------------

def fix_redundant_alias(line: str) -> str:
    """Remove redundant ``import X as X`` patterns."""
    m = re.match(
        r'^(\s*from\s+\S+\s+import\s+)(\w+)\s+as\s+(\w+)\s*$', line)
    if m and m.group(2) == m.group(3):
        return f'{m.group(1)}{m.group(2)}'
    return line


def fix_long_import(line: str) -> str:
    """Wrap long ``from … import Name`` into parenthesized form."""
    if len(line.rstrip()) <= MAX_LINE_LENGTH:
        return line
    m = re.match(r'^(\s*)from\s+(\S+)\s+import\s+(\w.*)$', line)
    if not m:
        return line
    indent, module, names = m.group(1), m.group(2), m.group(3).rstrip()
    if names.startswith('('):
        return line
    from_line = f'{indent}from {module} import ('
    if len(from_line) > MAX_LINE_LENGTH:
        from_line += '  # noqa: E501'
    return f'{from_line}\n{indent}    {names}\n{indent})'


def fix_long_line(line: str) -> str:
    """Add ``# noqa: E501`` to lines that cannot be structurally shortened."""
    if len(line.rstrip()) <= MAX_LINE_LENGTH:
        return line
    if '# noqa' in line:
        return line
    return line.rstrip() + '  # noqa: E501'


# ---------------------------------------------------------------------------
# File-specific fixes (Pyright + pylint + import)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Stubs module for import-test compatibility
# ---------------------------------------------------------------------------

STUBS_MODULE = '''\
"""Stubs for third-party packages used by the generated client.

This module is auto-generated by fix_sanity.py.  It allows the package
to be imported in environments where pydantic / urllib3 / dateutil are
not installed (e.g. ansible-test sanity --test import).
"""
from __future__ import (absolute_import, division, print_function)
# pylint: disable=invalid-name
__metaclass__ = type
# pylint: disable=unused-import,too-few-public-methods

from typing import Any, Dict, Generic, TypeVar

_T = TypeVar('_T')


# --- pydantic stubs ---


class BaseModel(Generic[_T]):
    """Stub BaseModel for import compatibility."""

    model_config: dict = {}

    def __init_subclass__(cls, **kw: Any) -> None:
        pass

    def __init__(self, **kw: Any) -> None:
        pass

    def to_dict(self) -> dict:
        return {}

    def to_json(self) -> str:
        return "{}"

    @classmethod
    def from_dict(cls, obj: Any) -> Any:
        return cls()

    @classmethod
    def from_json(cls, j: str) -> Any:
        return cls()

    @classmethod
    def model_validate(cls, obj: Any, **kw: Any) -> Any:
        return cls()


def ConfigDict(**kw: Any) -> Any:
    """Stub ConfigDict."""
    return {}


def Field(*a: Any, **kw: Any) -> Any:
    """Stub Field."""
    return None  # type: ignore


def validate_call(*a: Any, **kw: Any) -> Any:
    """Stub validate_call."""
    def decorator(fn: Any) -> Any:
        return fn
    if a and callable(a[0]):
        return a[0]
    return decorator


StrictStr = str
StrictInt = int
StrictFloat = float
StrictBool = bool


# --- typing_extensions stubs for Python 3.8 compatibility ---


class NotRequired:
    """Stub NotRequired for Python 3.8 compatibility."""

    def __class_getitem__(cls, item: Any) -> Any:
        return item


class Annotated:
    """Stub Annotated for Python 3.8 compatibility."""

    def __class_getitem__(cls, item: Any) -> Any:
        if isinstance(item, tuple) and item:
            return item[0]
        return item


class Literal:
    """Stub Literal for Python 3.7 compatibility."""

    def __class_getitem__(cls, item: Any) -> Any:
        return item


class ClassVar:
    """Stub ClassVar for Python 3.7 compatibility."""

    def __class_getitem__(cls, item: Any) -> Any:
        return item


# Create a base class for TypedDict inheritance
_TypedDictBase = dict


class TypedDictMeta(type):
    """Metaclass for TypedDict to support both function and class usage."""

    def __call__(cls, name: str = None, fields: Dict[str, Any] = None, total: bool = True, **kw: Any):
        """Support both TypedDict(name, fields) and TypedDict() for inheritance."""
        if name is not None and fields is not None:
            # Function call: TypedDict(name, fields)
            return type(name, (_TypedDictBase,), fields)
        else:
            # Class instantiation for inheritance
            return super().__call__()


class TypedDict(_TypedDictBase, metaclass=TypedDictMeta):
    """Stub TypedDict for Python 3.7 compatibility."""
    pass


Self = Any


StrictBytes = bytes
SecretStr = str


# --- urllib3 stubs ---


class _Util:
    """Stub urllib3.util."""

    @staticmethod
    def make_headers(**kw: Any) -> dict:
        return {}


class _Urllib3:
    """Stub urllib3 module."""

    HTTPResponse = object
    PoolManager = object
    ProxyManager = object
    util = _Util()

    class exceptions:  # pylint: disable=invalid-name
        """Stub urllib3.exceptions."""
        InsecureRequestWarning = type(
            "InsecureRequestWarning", (Warning,), {}
        )

    @staticmethod
    def disable_warnings(*a: Any, **kw: Any) -> None:
        pass


urllib3_stub = _Urllib3()


# --- dateutil stubs ---


class _DateutilParser:
    """Stub dateutil.parser."""

    @staticmethod
    def parse(s: str, **kw: Any) -> Any:
        return s


dateutil_parser_stub = _DateutilParser()
'''


def create_stubs_module(target_dir: Path) -> bool:
    """Write _stubs.py into the generated package."""
    stubs_path = target_dir / '_stubs.py'
    if stubs_path.exists() and stubs_path.read_text(encoding='utf-8') == STUBS_MODULE:
        return False
    stubs_path.write_text(STUBS_MODULE, encoding='utf-8')
    return True


def add_ansible_boilerplate(text: str) -> str:
    """Insert Ansible future-import and metaclass boilerplate after module docstring.

    Handles three cases:
    - Already has correct boilerplate: no-op.
    - Has ``from __future__ import annotations``: merge into combined form.
    - No future import: insert boilerplate after the module docstring.
    """
    if 'from __future__ import (absolute_import, division, print_function' in text:
        if '__metaclass__ = type' not in text:
            text = text.replace(
                'from __future__ import (absolute_import, division, print_function)\n',
                'from __future__ import (absolute_import, division, print_function)\n'
                '__metaclass__ = type\n',
            )
        return text

    # File already uses 'from __future__ import annotations' — combine all
    if 'from __future__ import annotations' in text:
        combined = (
            'from __future__ import (absolute_import, division, print_function)\n'
            '__metaclass__ = type'
        )
        text = text.replace('from __future__ import annotations', combined)
        return text

    # No future import at all — insert boilerplate after module docstring
    m = re.search(r'""".*?"""(?:\s*#[^\n]*)?\n', text, re.DOTALL)
    if m:
        pos = m.end()
        return text[:pos] + ANSIBLE_BOILERPLATE + text[pos:]
    return ANSIBLE_BOILERPLATE + text


def fix_self_annotation(text: str) -> str:
    """Remove modern typing annotations for Python 3.9 compatibility.

    Python 3.9 doesn't support:
    - typing.Self (added in 3.11)
    - Generic types like ApiResponse[ApiResponseT] (needs typing_extensions)
    - from typing import Self
    """
    # Only process files that contain problematic typing
    if 'Self' not in text and '[' not in text:
        return text

    # Remove all Self imports and references
    text = re.sub(r'from typing_extensions import Self.*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'from typing import Self.*$', '', text, flags=re.MULTILINE)
    text = re.sub(r',\s*Self\b', '', text)
    text = re.sub(r'Self\b,\s*', '', text)

    # Extract class name for Self replacements
    class_match = re.search(r'^class (\w+)', text, re.MULTILINE)
    class_name = class_match.group(1) if class_match else 'Any'

    # Replace Self type annotations with string equivalents
    text = re.sub(r'\) -> Self:', f") -> '{class_name}':", text)
    text = re.sub(r'Optional\[Self\]', f"Optional['{class_name}']", text)
    text = re.sub(r'List\[Self\]', f"List['{class_name}']", text)
    text = re.sub(r'Dict\[str, Self\]', f"Dict[str, '{class_name}']", text)
    text = re.sub(r'\bSelf\b', f"'{class_name}'", text)

    # Remove generic type annotations that don't work in Python 3.9
    # Replace things like -> ApiResponse[ApiResponseT]: with -> Any:
    text = re.sub(r'\) -> \w+\[[^\]]*\]:', ') -> Any:', text)
    text = re.sub(r': \w+\[[^\]]*\]', ': Any', text)
    text = re.sub(r'Optional\[\w+\[[^\]]*\]\]', 'Optional[Any]', text)
    text = re.sub(r'List\[\w+\[[^\]]*\]\]', 'List[Any]', text)
    text = re.sub(r'Dict\[str, \w+\[[^\]]*\]\]', 'Dict[str, Any]', text)
    text = re.sub(r'Union\[\w+\[[^\]]*\]', 'Union[Any]', text)
    text = re.sub(r'Union\[\w+, \w+\[[^\]]*\]\]', 'Union[Any, Any]', text)

    return text


def fix_typing_extensions_import(text: str) -> str:
    """Wrap ``from typing_extensions import …`` in try/except."""
    stubs_pkg = (
        'ansible_collections.dellemc.objectscale'
        '.plugins.module_utils.objectscale_client._stubs'
    )
    old = 'from typing_extensions import '
    if old not in text:
        return text
    m = re.search(r'^(from typing_extensions import .+)$', text, re.MULTILINE)
    if not m:
        return text
    orig_line = m.group(1)
    names = orig_line.replace('from typing_extensions import ', '').strip()
    replacement = (
        f'try:\n'
        f'    from typing_extensions import {names}\n'
        f'except ImportError:\n'
        f'    try:\n'
        f'        from typing import {names}  # Python 3.11+\n'
        f'    except ImportError:\n'
        f'        from {stubs_pkg} import {names}  # stub\n'
    )
    return text.replace(orig_line, replacement)


def fix_self_type_annotations(text: str) -> str:
    """Replace Self in type annotations with a string fallback for Python 3.8."""
    # Only replace Self in return type annotations (-> Self)
    # Don't replace in import statements or variable names
    text = re.sub(r'->\s*Self\b', "-> 'Self'", text)
    return text


def fix_configuration(text: str) -> str:
    """Fix Pyright errors specific to the generated configuration.py.

    0. Replace typing import with try/except for Literal/TypedDict (Python 3.7).
    1. Add ``import urllib3.util`` so Pyright resolves urllib3.util.make_headers.
    2. Add missing ``enum_values`` key to HostSettingVariable dicts.
    3. Rename disallowed ``_`` loop variable to ``_unused``.
    """
    stubs_pkg = (
        'ansible_collections.dellemc.objectscale'
        '.plugins.module_utils.objectscale_client._stubs'
    )

    # 0. Fix typing imports for Python 3.7 compatibility
    m = re.search(
        r'^from typing import (.+)$', text, re.MULTILINE
    )
    if m:
        names_str = m.group(1)
        names = [n.strip() for n in names_str.split(',')]
        problematic = {'Literal', 'ClassVar', 'TypedDict'}
        bad = [n for n in names if n in problematic]
        if bad:
            good = [n for n in names if n not in problematic]
            orig_line = m.group(0)
            good_import = f'from typing import {", ".join(good)}'
            bad_import = f'from {stubs_pkg} import {", ".join(bad)}'
            replacement = (
                f'try:\n'
                f'    {orig_line}\n'
                f'except ImportError:\n'
                f'    {good_import}\n'
                f'    {bad_import}'
            )
            text = text.replace(orig_line, replacement)

    # 1. Ensure urllib3.util is explicitly imported
    if 'import urllib3\n' in text and 'import urllib3.util' not in text:
        text = text.replace(
            'import urllib3\n',
            'import urllib3\nimport urllib3.util\n',
        )

    # 2. Add missing 'enum_values' to HostSettingVariable dicts.
    lines = text.split('\n')
    new_lines: list[str] = []
    for i, line in enumerate(lines):
        new_lines.append(line)
        if "'default_value'" in line and 'enum_values' not in line:
            indent = re.match(r'^(\s*)', line)
            if indent and i + 1 < len(lines) and lines[i + 1].strip() == '}':
                new_lines.append(f"{indent.group(1)}'enum_values': [],")
    text = '\n'.join(new_lines)

    # 3. Rename disallowed loop variable '_' to '_unused'
    text = text.replace('for _, logger in', 'for _unused, logger in')

    return text


def fix_api_client(text: str) -> str:
    """Fix pylint raising-bad-type false positive in api_client.py."""
    if '# pylint: disable=raising-bad-type' not in text:
        text = text.replace(
            'raise ApiException.from_response(',
            'raise ApiException.from_response(  # pylint: disable=raising-bad-type',
        )
    return text


def fix_third_party_imports(text: str, filepath: Path) -> str:
    """Wrap third-party imports (pydantic, urllib3, dateutil) in try/except.

    Falls back to stubs from ``_stubs.py`` so that ``ansible-test sanity
    --test import`` passes in a bare virtual-env.
    """
    stubs_pkg = (
        'ansible_collections.dellemc.objectscale.plugins'
        '.module_utils.objectscale_client._stubs'
    )

    # --- pydantic ---
    pydantic_imports = re.findall(
        r'^from pydantic import (.+)$', text, re.MULTILINE
    )
    if pydantic_imports:
        for names in pydantic_imports:
            orig = f'from pydantic import {names}'
            replacement = (
                f'try:\n'
                f'    from pydantic import {names}\n'
                f'except ImportError:\n'
                f'    from {stubs_pkg} import {names}  # stub'
            )
            text = text.replace(orig, replacement)

    # --- urllib3 ---
    if 'import urllib3' in text and 'try:\n    import urllib3' not in text:
        # Handle 'import urllib3' and 'import urllib3.util'
        lines = text.split('\n')
        new_lines = []
        urllib3_handled = False
        for line in lines:
            stripped = line.strip()
            if stripped in ('import urllib3', 'import urllib3.util') and not urllib3_handled:
                # Collect all urllib3 import lines
                if not urllib3_handled:
                    new_lines.append('try:')
                    new_lines.append('    import urllib3')
                    new_lines.append('    import urllib3.util')
                    new_lines.append('except ImportError:')
                    new_lines.append(f'    from {stubs_pkg} import urllib3_stub as urllib3  # stub')
                    urllib3_handled = True
            elif stripped == 'import urllib3.util' and urllib3_handled:
                pass  # already handled
            else:
                new_lines.append(line)
        text = '\n'.join(new_lines)

    # --- typing_extensions ---
    typing_ext_imports = re.findall(
        r'^from typing_extensions import (.+)$', text, re.MULTILINE
    )
    if typing_ext_imports:
        for names in typing_ext_imports:
            orig = f'from typing_extensions import {names}'
            replacement = (
                f'try:\n'
                f'    from typing_extensions import {names}\n'
                f'except ImportError:\n'
                f'    try:\n'
                f'        from typing import {names}  # Python 3.11+\n'
                f'    except ImportError:\n'
                f'        from {stubs_pkg} import {names}  # stub'
            )
            text = text.replace(orig, replacement)

    # --- dateutil ---
    if 'from dateutil.parser import parse' in text and 'try:\n    from dateutil.parser import parse' not in text:
        text = text.replace(
            'from dateutil.parser import parse',
            f'try:\n'
            f'    from dateutil.parser import parse\n'
            f'except ImportError:\n'
            f'    from {stubs_pkg} import dateutil_parser_stub as _dp  # stub\n'
            f'    parse = _dp.parse',
        )

    return text


# ---------------------------------------------------------------------------
# File processor
# ---------------------------------------------------------------------------

def process_file(filepath: Path) -> bool:
    """Process a single Python file. Returns True if modified."""
    original = filepath.read_text(encoding='utf-8')

    # Full-text pass: multi-line and single-line assert replacement
    text = fix_asserts(original)

    # Add Ansible boilerplate (future-import-boilerplate + metaclass-boilerplate)
    text = add_ansible_boilerplate(text)

    # Replace Self in type annotations for Python 3.8 compatibility
    text = fix_self_type_annotations(text)

    # Wrap typing_extensions imports in try/except (fixes import test)
    text = fix_typing_extensions_import(text)

    # Wrap all third-party imports in try/except with stubs
    text = fix_third_party_imports(text, filepath)

    # File-specific fixes
    if filepath.name == 'configuration.py':
        text = fix_configuration(text)
    if filepath.name == 'api_client.py':
        text = fix_api_client(text)

    # Line-level passes
    lines = text.split('\n')
    result = []
    for line in lines:
        line = fix_redundant_alias(line)
        # fix_long_import may produce multi-line output
        line = fix_long_import(line)
        # Apply noqa to any remaining long lines
        sub_lines = line.split('\n')
        result.extend(fix_long_line(sl) for sl in sub_lines)

    text = '\n'.join(result)

    # Collapse 3+ consecutive blank lines to 2 (fixes E303)
    while '\n\n\n\n' in text:
        text = text.replace('\n\n\n\n', '\n\n\n')
    # Also collapse 3 blank lines to 2 at module level
    text = re.sub(r'\n{4,}', '\n\n\n', text)

    if text != original:
        filepath.write_text(text, encoding='utf-8')
        return True
    return False


def main() -> None:
    parser = argparse.ArgumentParser(
        description='Post-process generated client code for ansible-test sanity')
    parser.add_argument(
        'directory', help='Directory containing generated client code')
    args = parser.parse_args()

    target = Path(args.directory)
    if not target.is_dir():
        print(f'Error: {target} is not a directory', file=sys.stderr)
        sys.exit(1)

    # Create _stubs.py for import-test compatibility
    if create_stubs_module(target):
        print(f'  Created: {target}/_stubs.py')

    fixed = 0
    for py_file in sorted(target.rglob('*.py')):
        if py_file.name == '_stubs.py':
            continue
        if process_file(py_file):
            fixed += 1
            print(f'  Fixed: {py_file}')

    print(f'Post-processed {fixed} file(s) in {target}')


if __name__ == '__main__':
    main()
