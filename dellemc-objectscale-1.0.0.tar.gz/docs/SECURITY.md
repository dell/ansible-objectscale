# Security policy

The Ansible modules for Dell ObjectScale repository is inspected for security vulnerabilities via blackduck scans and static code analysis.

In addition to this, there are various security checks that get executed against a branch when a pull request is created/updated.  Please refer to [pull request](https://github.com/dell/ansible-objectscale/blob/main/docs/CONTRIBUTING.md#Pull-requests) for more information.

## Reporting a vulnerability

Have you discovered a security vulnerability in this project?
We ask you to alert the maintainers by sending an email, describing the issue, impact, and fix - if applicable.

You can reach the Ansible modules for Dell ObjectScale maintainers at ansible.team@dell.com.
